import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';

// import MyCourses from '/student/my-courses';
import {router} from "../src/components/Other/Routes";


function App() {
  return (
   router
  );
}








export default App;
